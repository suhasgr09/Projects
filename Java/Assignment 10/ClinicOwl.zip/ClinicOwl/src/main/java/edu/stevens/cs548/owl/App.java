package edu.stevens.cs548.owl;

public class App {
	
	public static void main (String[] args) {
		
		new CliClient().cli();;
		
	}
	

}
